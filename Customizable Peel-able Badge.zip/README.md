
  # Customizable Peel-able Badge

  This is a code bundle for Customizable Peel-able Badge. The original project is available at https://www.figma.com/design/Em5nhy5Yqpa5lZyktgzc6I/Customizable-Peel-able-Badge.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  